# HAD Media website

Static site: open index.html, no build step.

Deploy on Vercel: push this folder to a GitHub repo, then Vercel > Add New Project > import the repo > Framework: Other > Deploy.
GitHub Pages: repo Settings > Pages > Deploy from branch > main / root.
